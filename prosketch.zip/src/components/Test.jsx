import React from 'react'

const Test = () => {
  // For testing we can use this component
  return (
    <div>Test</div>
  )
}

export default Test