import React from "react";
import Drawtool from "./components/Drawtool";

const App = () => {
  return (
    <div>
      <Drawtool />
    </div> 
  );
};

export default App;
