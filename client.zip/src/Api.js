let apiUrl = "http://localhost:1000"; 
// let apiUrl = "https://tamam.drawsketch.co";
export { apiUrl };
